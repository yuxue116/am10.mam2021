# https://github.com/wch/extrafont
# install.packages("extrafont")
library(extrafont)

library(tidyverse)
library(patchwork)

# import fonts - only once-- will look at system font folder
font_import()


# to get fonts from goole, go to https://fonts.google.com/ 
# Windows: use skyfonts to download google fonts on your computer https://www.fonts.com/web-fonts/google 
# if using skyfonts, point to the directory where google fonts live 
# on my windows machine this is @
font_import( paths="C:/Users/kchristodoulou/AppData/Roaming/Monotype/skyfonts-google")

# Alternatively?, you can download all of google fonts, by downloading and extracting 
# https://github.com/google/fonts/archive/master.zip (over 300 Mb) from https://github.com/google/fonts

extrafont::loadfonts(device="win")

# Vector of font family names
fonts()

plot <- 
ggplot(mtcars, aes(x=wt, y=mpg)) + 
  geom_point() +
  labs(
    title = "Fuel Efficiency of 32 Cars",
    x= "Weight (x1000 lb)",
    y = "Miles per Gallon"
  )+
  theme_minimal()+
  NULL

p1 <- plot + theme(text=element_text(size=16, family="Fira Sans"))
p2 <- plot + theme(text=element_text(size=16, family="Bahnschrift"))
p3 <- plot + theme(text=element_text(size=16, family="Oswald"))
p4 <- plot + theme(text=element_text(size=16, family="Rock Salt"))


# Use patchwork to arrange  4 graphs on same page
(p1 + p2) / (p3 + p4)



